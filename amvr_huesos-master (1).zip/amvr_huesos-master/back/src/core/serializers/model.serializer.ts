export class ModelEntity {
  id: number;
  [key: string]: any;
}