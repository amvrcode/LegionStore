import { IProduct } from '../../product/interfaces/product.interface'

export interface IProductInput {
  product: IProduct
  title: string
}
