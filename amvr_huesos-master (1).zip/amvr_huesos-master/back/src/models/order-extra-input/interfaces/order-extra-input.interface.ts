import { IOrder } from '../../order/interfaces/order.interface'

export interface IOrderExtraInput {
  order: IOrder
  value: string
}
